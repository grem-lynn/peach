const form = document.querySelector('form');
const input = document.querySelector('input');

form.addEventListener('submit', async event => {
    event.preventDefault();
    window.navigator.serviceWorker.register('./sw.js', {
        scope: __uv$config.prefix
    }).then(() => {
        let url = input.value.trim();
        if (!isUrl(url)) url = 'https://www.google.com/search?q=' + url;
        else if (!(url.startsWith('https://') || url.startsWith('http://'))) url = 'http://' + url;


        window.location.href = __uv$config.prefix + __uv$config.encodeUrl(url);
    });
});

function isUrl(val = ''){
    if (/^http(s?):\/\//.test(val) || val.includes('.') && val.substr(0, 1) !== ' ') return true;
    return false;
};

function unencodeSpans() {
  // Get all the span elements on the page
  const spans = document.getElementsByTagName('span');

  // Loop through all the span elements
  for (let i = 0; i < spans.length; i++) {
    const span = spans[i];

    // Check if the HTML content of the span contains 'Ã—'
    if (span.innerHTML.includes('Ã—')) {

      // Replace 'Ã—' with 'X'
      const newHtml = span.innerHTML.replace(/Ã—/g, 'X');

      // Set the new HTML content for the span
      span.innerHTML = newHtml;
    }
  }
}